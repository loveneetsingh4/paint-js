/**
 * @author yan
 */

function test(){
	gsdgds
}

(function(){
	var a = 1;
	/*
	 * a
	 */
	var b;
	
	var c = function(){
		
	};
	
	c.prototype = {
		a:function(){
			
		},
		b:function(){
			
		},
	}
}());
